/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * 
 * https://tsanaung.github.io
 */

 /*
 var app = new Vue({
    el: '#app',
    data: {
        message: 'Hello World!'
    }
 })
 */

/*
import axios from 'axios';
const apiURL = 'https://globalmyanmarmedia.com/wp-json/wp/v2/posts';

export class Data {
    posts: string;
    public constructor () {
      axios.get(apiURL)
        .then(response => {
          this.posts = response.data;
          console.log(this.posts);
        })
        .catch(error => console.log(error));
    }
}
*/

/*
import axios from 'axios';
export const HTTP = axios.create({
    baseURL: 'https://globalmyanmarmedia.com/wp-json/wp/v2/'
})
*/

/*
var flink = "{{post.better_featured_image.media_details.file}}";
var fmedialink = "https://globalmyanmarmedia.com/wp-content/uploads"+"{{post.better_featured_image.media_details.file}}"
var fimgc = "\"\/\>";

document.getElementById("fimg").innerHTML = fmedialink; 
*/




new Vue({
  el: '#app',
  data: {
    posts: []
  },
  created () {

    var vm = this
    axios.get('https://globalmyanmarmedia.com/wp-json/wp/v2/posts')
      .then(function (response) {
        vm.posts = response.data
      })

  }
})

/*

var apptest = new Vue({
    
    el: "#app",
    data: {
        collapsed: true
    }
}); 
*/

/*
var vm = new Vue({
  el: '#example',
  data: {
    message: '123'
  }
})
vm.message = 'new message' // change data
vm.$el.textContent === 'new message' // false
Vue.nextTick(function () {
  vm.$el.textContent === 'post.content.rendered' // true
})
*/


/* Test 
new Vue({
    el: '#app-test',
    data: {
        isOpen: false
    },
    methods:{
        toggle: function(){
            this.isOpen = !this.isOpen
        }
    }
});

*/



/*var solink = document.getElementById("solink");
/*document.getElementById("ffimg").src = "/{/{post.better_featured_image.source_url/}/}";

/*document.getElementById("soimg").innerHTML = ; 

var apiURL = 'https://globalmyanmarmedia.com/wp-json/wp/v2/posts/?_embed&per_page=3&author='

/**
 * Posts demo with ability to change author
 

var posts = new Vue({

    el: '#app',

    data: {
        authors: ['1', '590'],
        currentAuthor: '1',
        posts: null
    },

    created: function() {
        this.fetchData()
    },

    watch: {
        currentAuthor: 'fetchData'
    },

    methods: {
        fetchData: function() {
            var xhr = new XMLHttpRequest()
            var self = this
            xhr.open('GET', apiURL + self.currentAuthor)
            xhr.onload = function() {
                self.posts = JSON.parse(xhr.responseText)
                console.log(self.posts[0].link)
            }
            xhr.send()
        }
    }
})

*/